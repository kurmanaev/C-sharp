﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dz_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int first = 0, second = 0;
            
            Console.WriteLine("Enter the first number");
            first=Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the second number");
            second = Convert.ToInt32(Console.ReadLine());
            int min = first, max=second;

           

            if (first>second) { max=first; min=second; } 

            for (int i = min; i <= max; i++)
            {
                if (i % 2 == 0) { Console.WriteLine(i); }
            }
            Console.ReadKey();
        }
    }
}
